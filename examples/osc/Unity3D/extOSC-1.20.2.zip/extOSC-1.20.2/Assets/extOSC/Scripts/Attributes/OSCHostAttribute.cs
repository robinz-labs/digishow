﻿/* Copyright (c) 2022 dr. ext (Vladimir Sigalkin) */

using UnityEngine;

namespace extOSC
{
	public class OSCHostAttribute : PropertyAttribute
	{ }
}